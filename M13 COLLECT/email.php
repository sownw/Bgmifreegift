<?php
$emailku = 'aman61w@gmail.com'; // GANTI EMAIL KAMU DISINI
?>