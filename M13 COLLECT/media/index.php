
<!--- made with love by arfan rizki ramadhan --->

<html>
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="arpanrizki">
<meta name="description" content="This website made by Arfan Rizki Ramadhan">
<meta property="og:description" content="This website made by Arfan Rizki Ramadhan">
<meta property="og:url" content="./">
<meta property="og:site_name" content="arpanrizki">
<meta property="og:type" content="website">
<meta name="copyright"content="arpanrizki">
<meta name="theme-color" content="#000">
<meta property="og:image" content="This website made by Arfan Rizki Ramadhan">
<title>arpanrizki</title>
<link href="https://fonts.googleapis.com/css2?family=Bubblegum+Sans&family=Staatliches&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="icon" href="https://images.vexels.com/media/users/3/143495/isolated/preview/6b80b9965b1ec4d47c31d7eccf8ce4b0-yellow-lightning-bolt-icon-by-vexels.png">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<style>
body {
 background: url(https://i.ibb.co/mDBHbq0/tedward-quinn-oqg-XEr-Mq-Knc-unsplash.jpg) no-repeat center center;
 background-size: cover;
 margin: 0px;
 padding: 0px;
}
.bungkusan {
 background: rgba(0, 0, 0, 0.4);
 width: 100%;
 height: 100%;
}
.container {
 max-width: 400px;
 height: auto;
 margin-left: auto;
 margin-right: auto;
 display: block;
}
.tulisan {
 padding-top: 50%;
 color: #fff;
 font-size: 30px;
 font-family: 'Bubblegum Sans', cursive;
 text-align: center;
}
.tulisan i {
 color: #fff;
 margin-left: auto;
 margin-right: auto;
 margin-bottom: 20px;
 display: block;
}
button {
 background: #fff;
 width: auto;
 height: auto;
 margin-top: 15px;
 margin-left: auto;
 margin-right: auto;
 padding: 8px;
 padding-left: 12px;
 padding-right: 12px;
 color: #000;
 font-size: 15px;
 font-family: 'Bubblegum Sans', cursive;
 text-align: center;
 border: none;
 border-radius: 30px;
 outline: none;
 display: block;
}
</style>

<div class="bungkusan">

<div class="container">
<div class="tulisan">
<i class="zmdi zmdi-settings zmdi-hc-4x zmdi-hc-spin"></i>
are you looking for this script?
</div>
<a onclick='location.href="https://t.me/berbagisc";' class="p"><button>Click Here</button>
</div>

</div>

</body>
</html>

<!--- made with love by arfan rizki ramadhan --->
